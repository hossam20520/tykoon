



function initMap(){var e={lat:30.081717,lng:31.347598},t=new google.maps.Map(document.getElementById("map"),{zoom:13,center:e});new google.maps.Marker({position:e,map:t,title:"El-Thawra St, Cairo Governorate"})};

